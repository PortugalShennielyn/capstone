<?php
require_once __DIR__ . '/auth_page_guard.php';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr. R Pharmacy | Owner PO Approval</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <link href="./css/navbar.css?v=15" rel="stylesheet">
    <script src="./js/navbar.js?v=28" defer></script>
    <script type="module" src="./js/modules/auth_guard.js?v=6"></script>

    <style>
        :root {
            --sidebar-width: 260px;
            --sidebar-collapsed-width: 70px;
            --purple: #7c3aed;
            --purple-dark: #6328d6;
            --body-bg: #f4f6fb;
            --topbar-height: 70px;
            --border-soft: #e8ecf3;
            --text-main: #252b37;
            --transition: all .3s ease;
        }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; color: var(--text-main); background: var(--body-bg); font-family: "Inter", sans-serif; letter-spacing: 0; }
        body.dark-mode { --body-bg: #111827; --border-soft: #263244; --text-main: #e5e7eb; }
        .main-wrapper { min-height: 100vh; margin-left: var(--sidebar-width); transition: var(--transition); }
        .main-wrapper.collapsed { margin-left: var(--sidebar-collapsed-width); }
        .topbar { position: sticky; top: 0; height: var(--topbar-height); display: flex; align-items: center; justify-content: space-between; padding: 0 26px; background: #fff; border-bottom: 1px solid var(--border-soft); z-index: 1020; }
        body.dark-mode .topbar, body.dark-mode .card, body.dark-mode .summary-card { background: #182131; color: var(--text-main); }
        .topbar-left, .topbar-right { display: flex; align-items: center; gap: 14px; }
        .icon-btn { width: 42px; height: 42px; display: inline-flex; align-items: center; justify-content: center; border: 0; border-radius: 8px; color: #4b5563; background: #f4f6fb; }
        .icon-btn:hover { color: #fff; background: var(--purple); }
        .page-title-mini { display: flex; flex-direction: column; line-height: 1.2; }
        .page-title-mini strong { color: var(--text-main); font-size: 15px; font-weight: 800; }
        .page-title-mini span { margin-top: 3px; color: #7b8494; font-size: 12px; font-weight: 600; }
        .page-body { padding: clamp(22px, 2vw, 34px); }
        .workspace { width: 100%; max-width: 1600px; margin: 0 auto; padding-inline: clamp(8px, 1.1vw, 18px); }
        body.navbar-sidebar-collapsed .workspace { max-width: 1700px; padding-inline: clamp(10px, 1.4vw, 24px); }
        .card, .summary-card { border: 1px solid var(--border-soft); border-radius: 10px; box-shadow: 0 8px 22px rgba(15,23,42,.045); }
        .approval-summary-grid { display: grid; grid-template-columns: repeat(4, minmax(170px, 1fr)); gap: 12px; margin-bottom: 18px; }
        .summary-card { min-height: 92px; display: flex; flex-direction: column; justify-content: center; gap: 7px; padding: 15px 16px; background: #fff; border-left: 4px solid var(--card-color, #f59e0b); }
        .summary-card strong { display: block; font-size: clamp(1.18rem, 1.45vw, 1.52rem); font-weight: 850; line-height: 1.05; white-space: nowrap; }
        .summary-card p { margin: 0; color: #596274; font-size: .82rem; font-weight: 800; line-height: 1.25; }
        .btn-purple { --bs-btn-color:#fff; --bs-btn-bg:var(--purple); --bs-btn-border-color:var(--purple); --bs-btn-hover-color:#fff; --bs-btn-hover-bg:var(--purple-dark); --bs-btn-hover-border-color:var(--purple-dark); }
        .section-title { color: var(--text-main); font-size: 1.05rem; font-weight: 800; }
        .approval-filter-bar { display: flex; flex-wrap: wrap; gap: 10px; align-items: end; padding: 12px; margin-bottom: 12px; border: 1px solid var(--border-soft); border-radius: 10px; background: #f8f9fc; }
        .approval-filter-field label { display: block; margin-bottom: 4px; color: #596274; font-size: 11px; font-weight: 850; text-transform: uppercase; }
        .approval-filter-field .form-control, .approval-filter-field .form-select { min-height: 36px; font-size: 12px; font-weight: 700; }
        .approval-filter-field-start, .approval-filter-field-end { flex: 0 0 170px; }
        .approval-filter-field-month { flex: 0 0 180px; }
        .approval-filter-field-year { flex: 0 0 150px; }
        .approval-filter-actions { display: inline-flex; gap: 8px; align-items: end; flex: 0 0 auto; }
        .approval-filter-actions .btn, .approval-tabs-toolbar .btn { width: 40px; min-width: 40px; height: 36px; display: inline-flex; align-items: center; justify-content: center; padding: 0; }
        .approval-period-label { display: inline-flex; flex-wrap: wrap; gap: 5px; margin-bottom: 10px; color: #596274; font-size: 12px; font-weight: 750; }
        .approval-period-label strong { color: var(--text-main); }
        .approval-tabs-toolbar { display: inline-flex; align-items: center; gap: 8px; margin-bottom: 10px; }
        .approval-tab-switch { display: inline-flex; flex-wrap: wrap; gap: 6px; padding: 4px; border: 1px solid var(--border-soft); border-radius: 10px; background: #f8f9fc; }
        .approval-tab-btn { min-width: 96px; border: 0; border-radius: 8px; padding: 7px 12px; color: #596274; background: transparent; font-size: 12px; font-weight: 800; }
        .approval-tab-btn.active { color: #fff; background: var(--purple); box-shadow: 0 8px 16px rgba(124,58,237,.2); }
        .table-responsive { border-radius: 10px; overflow-x: auto; scrollbar-gutter: stable; }
        .pending-table { width: max-content; min-width: 2070px; margin-bottom: 0; table-layout: fixed; border-collapse: separate; border-spacing: 0; }
        .pending-table th { padding: 13px 10px; color: #596274; background: #f8f9fc; font-size: 12.5px; font-weight: 800; line-height: 1.18; text-align: center; white-space: nowrap; vertical-align: middle; }
        .pending-table td { padding: 14px 10px; color: var(--text-main); font-size: 12.5px; font-weight: 750; line-height: 1.34; text-align: center; vertical-align: middle; white-space: normal; overflow-wrap: break-word; word-break: normal; hyphens: none; }
        .pending-table th:nth-child(1), .pending-table td:nth-child(1) { width: 130px; min-width: 130px; white-space: nowrap; }
        .pending-table th:nth-child(2), .pending-table td:nth-child(2) { width: 210px; min-width: 210px; text-align: left; }
        .pending-table th:nth-child(3), .pending-table td:nth-child(3) { width: 160px; min-width: 160px; text-align: left; }
        .pending-table th:nth-child(4), .pending-table td:nth-child(4) { width: 150px; min-width: 150px; text-align: left; }
        .pending-table th:nth-child(5), .pending-table td:nth-child(5) { width: 180px; min-width: 180px; text-align: left; }
        .pending-table th:nth-child(6), .pending-table td:nth-child(6) { width: 260px; min-width: 260px; text-align: left; }
        .pending-table th:nth-child(7), .pending-table td:nth-child(7) { width: 100px; min-width: 100px; }
        .pending-table th:nth-child(8), .pending-table td:nth-child(8) { width: 140px; min-width: 140px; text-align: right; }
        .pending-table th:nth-child(9), .pending-table td:nth-child(9) { width: 150px; min-width: 150px; text-align: right; }
        .pending-table th:nth-child(10), .pending-table td:nth-child(10) { width: 130px; min-width: 130px; white-space: nowrap; }
        .pending-table th:nth-child(11), .pending-table td:nth-child(11) { width: 150px; min-width: 150px; }
        .pending-table th:nth-child(12), .pending-table td:nth-child(12) { width: 120px; min-width: 120px; text-align: center; white-space: nowrap; }
        .pending-table th:nth-child(13), .pending-table td:nth-child(13) { width: 130px; min-width: 130px; }
        .pending-table th:last-child,
        .pending-table td:last-child {
            position: sticky;
            right: 0;
            z-index: 5;
            background: var(--bs-table-bg, #fff);
            border-left: 1px solid #e5e9f1;
            box-shadow: -6px 0 10px rgba(15, 23, 42, .06);
        }
        .pending-table th:last-child { z-index: 7; background: #f8f9fc; }
        .pending-table tbody tr:hover td:last-child { background: var(--bs-table-hover-bg, #f6f1ff); }
        .pending-table td[colspan] { position: static !important; right: auto !important; border-left: 0 !important; box-shadow: none !important; }
        .approval-line-list { display: grid; gap: 4px; margin: 0; padding: 0; list-style: none; text-align: left; }
        .approval-line-list li { display: grid; grid-template-columns: 18px minmax(0, 1fr); gap: 5px; align-items: start; min-height: 18px; }
        .approval-line-list .line-index { color: #7b8494; font-size: 12px; font-weight: 800; text-align: right; line-height: 1.3; }
        .approval-line-list .line-text { min-width: 0; line-height: 1.3; white-space: normal; overflow-wrap: break-word; word-break: normal; hyphens: none; }
        .approval-line-list-compact .line-text { white-space: normal; overflow-wrap: break-word; word-break: normal; hyphens: none; }
        #table-pending-orders td.approval-supplier-cell,
        #table-pending-orders td.approval-items-cell,
        #table-pending-orders td.approval-items-cell * { overflow-wrap: break-word !important; word-break: normal !important; hyphens: none !important; }
        .approval-line-list-plain { text-align: center; }
        .approval-line-list-plain li { grid-template-columns: 1fr; justify-items: center; }
        .approval-money-cell { white-space: nowrap; font-weight: 850; text-align: right !important; }
        .approval-status-badge { white-space: nowrap; line-height: 1.2; font-size: 11px; padding: 6px 8px; }
        .approval-actions { display: inline-flex; flex-wrap: nowrap; justify-content: center; align-items: center; gap: 8px; white-space: nowrap; min-width: max-content; }
        .approval-actions .btn { width: 32px; height: 32px; min-width: 32px; display: inline-flex; align-items: center; justify-content: center; padding: 0; }
        .approval-actions .btn:disabled { opacity: .48; cursor: not-allowed; }
        .approval-empty { padding: 42px 16px !important; color: #8790a1 !important; text-align: center; }
        #pendingOrderViewModal {
            --approval-modal-width: min(1040px, calc(100vw - 48px));
            --approval-modal-height: min(85vh, calc(100vh - 32px));
        }
        #pendingOrderViewModal .modal-dialog { width: var(--approval-modal-width); max-width: min(1120px, calc(100vw - 32px)); height: auto; max-height: 85vh; }
        #pendingOrderViewModal.approval-modal-positioned .modal-dialog { position: fixed; left: var(--approval-modal-left, 50%); top: var(--approval-modal-top, 24px); width: var(--approval-modal-width); height: var(--approval-modal-height); margin: 0; transform: none; }
        #pendingOrderViewModal .modal-content { position: relative; display: flex; flex-direction: column; max-height: 85vh; min-width: min(680px, calc(100vw - 24px)); overflow: hidden; }
        #pendingOrderViewModal .modal-header { position: relative; z-index: 30; flex: 0 0 auto; background: #f8fafc; cursor: move; user-select: none; }
        #pendingOrderViewModal .modal-header .btn-close { cursor: pointer; }
        #pendingOrderViewModal .modal-body { flex: 1 1 auto; min-height: 0; padding: 12px 16px; overflow: auto; background: #f3f6fb; scrollbar-gutter: stable; }
        #pendingOrderViewModal .modal-footer { flex: 0 0 auto; background: #f8fafc; z-index: 25; }
        .approval-modal-corner-resize { position: absolute; right: 6px; bottom: 6px; z-index: 35; width: 18px; height: 18px; cursor: nwse-resize; border-right: 3px solid rgba(124, 58, 237, .55); border-bottom: 3px solid rgba(124, 58, 237, .55); border-radius: 0 0 6px 0; touch-action: none; }
        .approval-modal-corner-resize:hover, .approval-modal-corner-resize.is-dragging { border-color: #f97316; }
        .po-detail-grid { display: grid; grid-template-columns: repeat(4, minmax(0, 1fr)); gap: 8px; margin-bottom: 10px !important; }
        .po-detail-box { min-height: 72px; padding: 10px 12px; border: 1px solid var(--border-soft); border-radius: 8px; background: #f8f9fc; }
        .po-detail-box span { display: block; color: #7b8494; font-size: .72rem; font-weight: 800; line-height: 1.2; text-transform: uppercase; }
        .po-detail-box strong { display: block; margin-top: 5px; color: var(--text-main); font-size: .9rem; font-weight: 800; line-height: 1.35; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .po-detail-chip { min-width: 0; padding: 8px 10px; border: 1px solid #e1e7f0; border-radius: 8px; background: #fff; }
        .po-detail-chip span { display: block; color: #667085; font-size: 10.5px; font-weight: 850; line-height: 1.2; text-transform: uppercase; }
        .po-detail-chip strong { display: block; margin-top: 4px; color: #172033; font-size: 13px; font-weight: 850; line-height: 1.25; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .po-summary-strip { grid-column: 1 / -1; display: grid; grid-template-columns: minmax(160px, 1.2fr) repeat(2, minmax(140px, .8fr)); gap: 8px; padding: 7px 8px; border: 1px solid #d8e2f4; border-radius: 8px; background: #eef4ff; }
        .po-summary-strip div { min-width: 0; }
        .po-summary-strip span { display: block; color: #56657a; font-size: 10.5px; font-weight: 850; line-height: 1.2; text-transform: uppercase; }
        .po-summary-strip strong { display: block; margin-top: 3px; color: #4730a3; font-size: 14px; font-weight: 900; line-height: 1.2; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .approval-pill { display: inline-flex !important; width: fit-content; max-width: 100%; padding: 4px 8px; border-radius: 999px; font-size: 11px !important; line-height: 1.15 !important; }
        .approval-pill.is-pending { color: #92400e; background: #fef3c7; }
        .approval-pill.is-logistics { color: #1e3a8a; background: #dbeafe; }
        .approval-pill.is-approved { color: #166534; background: #dcfce7; }
        .approval-pill.is-rejected { color: #991b1b; background: #fee2e2; }
        .approval-pill.is-revision { color: #6d28d9; background: #ede9fe; }
        .approval-items-header { display: flex; align-items: center; justify-content: space-between; gap: 12px; margin-bottom: 7px; }
        .approval-items-header h3 { margin: 0; color: #172033; font-size: 15px; font-weight: 900; }
        .approval-items-header span { color: #64748b; font-size: 12px; font-weight: 800; }
        .approval-items-list { display: grid; gap: 8px; }
        .approval-item-card { display: grid; grid-template-columns: minmax(250px, 1fr) minmax(420px, 1.35fr); gap: 12px; align-items: start; padding: 9px 11px; border: 1px solid #dfe7f2; border-radius: 8px; background: #fff; box-shadow: 0 5px 14px rgba(15, 23, 42, .035); }
        .approval-item-main { display: grid; grid-template-columns: 26px minmax(0, 1fr); gap: 8px; min-width: 0; }
        .approval-item-index { width: 26px; height: 26px; display: inline-flex; align-items: center; justify-content: center; border-radius: 8px; color: #4f46e5; background: #eef2ff; font-size: 12px; font-weight: 900; }
        .approval-item-copy { min-width: 0; }
        .approval-item-copy h3 { margin: 0; color: #111827; font-size: 14px; font-weight: 900; line-height: 1.25; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .approval-item-copy p { margin: 3px 0 0; color: #475569; font-size: 11.5px; font-weight: 800; line-height: 1.25; }
        .approval-item-copy span { display: block; margin-top: 3px; color: #667085; font-size: 11.5px; font-weight: 700; line-height: 1.3; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .approval-item-decision { display: grid; gap: 7px; min-width: 0; }
        .approval-item-facts { display: grid; grid-template-columns: .65fr 1.25fr .9fr .9fr; gap: 7px; min-width: 0; align-items: start; }
        .approval-item-facts div { min-width: 0; }
        .approval-item-facts span { display: block; color: #667085; font-size: 10px; font-weight: 850; line-height: 1.15; text-transform: uppercase; }
        .approval-item-facts strong { display: block; margin-top: 3px; color: #172033; font-size: 12px; font-weight: 850; line-height: 1.25; white-space: normal; overflow-wrap: break-word; word-break: normal; }
        .approval-item-total strong { color: #5b21b6; font-size: 13px; }
        .approval-inventory-strip { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; min-width: 0; color: #64748b; font-size: 11px; font-weight: 800; line-height: 1.2; }
        .approval-inventory-label { color: #334155; font-weight: 900; }
        .approval-inventory-chip { display: inline-flex; align-items: baseline; gap: 4px; min-width: 0; padding: 3px 7px; border: 1px solid #e3eaf4; border-radius: 999px; background: #f8fafc; white-space: nowrap; }
        .approval-inventory-chip span { color: #687386; font-size: 10.5px; font-weight: 850; }
        .approval-inventory-chip strong { color: #172033; font-size: 11.5px; font-weight: 900; }
        .approval-modal-actions { display: inline-flex; gap: 8px; align-items: center; }
        body.dark-mode .pending-table th { background: #202b3d; color: #cbd5e1; }
        body.dark-mode .pending-table th:last-child { background: #202b3d; }
        body.dark-mode .pending-table td:last-child { background: var(--bs-table-bg, #182131); border-left-color: #263244; }
        body.dark-mode .pending-table tbody tr:hover td:last-child { background: var(--bs-table-hover-bg, #202b3d); }
        body.dark-mode .approval-tab-switch { background: #182131; border-color: #263244; }
        body.dark-mode .approval-filter-bar { background: #182131; border-color: #263244; }
        body.dark-mode .po-detail-box { background: #182131; }
        body.dark-mode #pendingOrderViewModal .modal-body { background: #111827; }
        body.dark-mode .po-detail-chip,
        body.dark-mode .approval-item-card,
        body.dark-mode .po-summary-strip,
        body.dark-mode .approval-inventory-label,
        body.dark-mode .approval-inventory-chip { background: #182131; border-color: #263244; }
        body.dark-mode #pendingOrderViewModal .modal-header,
        body.dark-mode #pendingOrderViewModal .modal-body,
        body.dark-mode #pendingOrderViewModal .modal-footer { background: #182131; }
        @media (max-width: 991.98px) {
            .page-body { padding: 20px 14px; }
            .workspace { max-width: 100%; padding-inline: 0; }
            .approval-summary-grid { grid-template-columns: repeat(2, minmax(150px, 1fr)); }
            .approval-filter-field-start, .approval-filter-field-end,
            .approval-filter-field-month, .approval-filter-field-year { flex: 1 1 170px; }
            .po-detail-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .approval-item-card { grid-template-columns: 1fr; }
            .approval-item-facts { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .po-summary-strip { grid-template-columns: 1fr; }
        }
        @media (max-width: 575.98px) {
            .approval-summary-grid { grid-template-columns: 1fr; }
            .approval-filter-field-start, .approval-filter-field-end,
            .approval-filter-field-month, .approval-filter-field-year,
            .approval-filter-actions { flex: 1 1 100%; }
            .approval-filter-actions .btn { width: 100%; }
            .po-detail-grid,
            .approval-item-facts { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div id="navbar-container"></div>

    <main class="main-wrapper" id="mainWrapper">
        <header class="topbar">
            <div class="topbar-left">
                <button class="icon-btn" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="page-title-mini">
                    <strong>Owner PO Approval</strong>
                    <span>Review purchase orders before processing</span>
                </div>
            </div>
            <div class="topbar-right">
                <button class="icon-btn" type="button" aria-label="Notifications">
                    <i class="fa-regular fa-bell"></i>
                </button>
                <button class="icon-btn" type="button" id="themeToggle" aria-label="Toggle dark mode">
                    <i class="fa-solid fa-moon"></i>
                </button>
            </div>
        </header>

        <section class="page-body">
            <div class="workspace">
                <div class="approval-summary-grid">
                    <div class="summary-card" style="--card-color:#f59e0b">
                        <strong id="pendingApprovalCount">0</strong>
                        <p>Pending Approval</p>
                    </div>
                    <div class="summary-card" style="--card-color:#16a34a">
                        <strong id="approvedApprovalCount">0</strong>
                        <p>Approved Orders</p>
                    </div>
                    <div class="summary-card" style="--card-color:#dc2626">
                        <strong id="rejectedApprovalCount">0</strong>
                        <p>Rejected Orders</p>
                    </div>
                    <div class="summary-card" style="--card-color:#7c3aed">
                        <strong id="overallPoAmount">?0.00</strong>
                        <p>Overall PO Amount</p>
                    </div>
                </div>

                <div class="card p-3">
                    <div class="mb-3">
                        <div>
                            <h1 class="section-title mb-1">Owner Approval Queue</h1>
                            <p class="text-muted small mb-0">Approve or reject purchase orders before they continue processing.</p>
                        </div>
                    </div>
                    <div class="approval-filter-bar" aria-label="Purchase order approval filters">
                        <div class="approval-filter-field approval-filter-field-start">
                            <label for="approvalStartDate">Start Date</label>
                            <input id="approvalStartDate" class="form-control" type="date">
                        </div>
                        <div class="approval-filter-field approval-filter-field-end">
                            <label for="approvalEndDate">End Date</label>
                            <input id="approvalEndDate" class="form-control" type="date">
                        </div>
                        <div class="approval-filter-field approval-filter-field-month">
                            <label for="approvalMonth">Month</label>
                            <select id="approvalMonth" class="form-select">
                                <option value="">All Months</option>
                            </select>
                        </div>
                        <div class="approval-filter-field approval-filter-field-year">
                            <label for="approvalYear">Year</label>
                            <select id="approvalYear" class="form-select">
                                <option value="">All Years</option>
                            </select>
                        </div>
                        <div class="approval-filter-actions">
                            <button class="btn btn-purple btn-sm px-3 w-auto" type="button" id="btnApplyApprovalFilters">Apply</button>
                        </div>
                    </div>
                    <div class="approval-tabs-toolbar">
                        <div class="approval-tab-switch" role="group" aria-label="Approval status tabs">
                            <button class="approval-tab-btn active" type="button" data-approval-view="pending">Pending</button>
                            <button class="approval-tab-btn" type="button" data-approval-view="approved">Approved</button>
                            <button class="approval-tab-btn" type="button" data-approval-view="revision">Revision Requested</button>
                            <button class="approval-tab-btn" type="button" data-approval-view="rejected">Rejected</button>
                        </div>
                        <button class="btn btn-outline-secondary btn-sm" type="button" id="btnRefreshPendingOrders" title="Refresh" aria-label="Refresh approvals">
                            <i class="fa-solid fa-rotate"></i>
                        </button>
                    </div>
                    <div class="approval-period-label" id="approvalPeriodLabel">
                        <span>Showing:</span><strong>All purchase orders</strong>
                    </div>
                    <div class="table-responsive">
                        <table id="table-pending-orders" class="table table-hover align-middle pending-table">
                            <thead>
                                <tr>
                                    <th>Order Date</th>
                                    <th>PO Number</th>
                                    <th>Supplier</th>
                                    <th>Brand</th>
                                    <th>Product</th>
                                    <th>Specification</th>
                                    <th>Order Qty</th>
                                    <th>Total Amount</th>
                                    <th>Adjusted Amount</th>
                                    <th>ETA</th>
                                    <th>Approval Status</th>
                                    <th>Reason</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td colspan="13" class="approval-empty">Loading purchase orders...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <div class="modal fade" id="pendingOrderViewModal" tabindex="-1" aria-labelledby="pendingOrderViewModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h2 class="modal-title fs-5 fw-bold" id="pendingOrderViewModalLabel">Purchase Order Approval Details</h2>
                        <p class="text-muted small mb-0 mt-1" id="pendingViewPoNumber">Review complete order information.</p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="pendingViewDetails" class="po-detail-grid"></div>
                    <div class="approval-items-header">
                        <h3>Items for Approval</h3>
                        <span id="pendingViewItemCount">0 items</span>
                    </div>
                    <div id="pendingViewItems" class="approval-items-list"></div>
                </div>
                <div class="modal-footer">
                    <div id="pendingModalApprovalActions" class="approval-modal-actions d-none">
                        <button class="btn btn-outline-danger modal-reject-po-btn" type="button">
                            <i class="fa-solid fa-xmark me-1"></i>Reject
                        </button>
                        <button class="btn btn-success modal-approve-po-btn" type="button">
                            <i class="fa-solid fa-check me-1"></i>Approve
                        </button>
                    </div>
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
                <div id="pending-modal-corner-resize" class="approval-modal-corner-resize" aria-hidden="true"></div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script type="module" src="./js/modules/pending_orders.js?v=20"></script>
    <script type="module">
        import verifySession from './js/modules/auth.js';
        await verifySession();
    </script>
</body>
</html>

