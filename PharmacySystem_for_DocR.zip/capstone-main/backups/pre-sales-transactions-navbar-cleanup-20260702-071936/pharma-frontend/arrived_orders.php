<?php
require_once __DIR__ . '/auth_page_guard.php';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr. R Pharmacy | Arrived Orders</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <link href="./css/navbar.css?v=15" rel="stylesheet">
    <script src="./js/navbar.js?v=28" defer></script>
    <script type="module" src="./js/modules/auth_guard.js?v=6"></script>

    <style>
        :root { --sidebar-width:260px; --sidebar-collapsed-width:70px; --purple:#7c3aed; --purple-dark:#6328d6; --body-bg:#f4f6fb; --topbar-height:70px; --border-soft:#e8ecf3; --text-main:#252b37; --transition:all .3s ease; }
        * { box-sizing:border-box; }
        body { margin:0; min-height:100vh; color:var(--text-main); background:var(--body-bg); font-family:"Inter", sans-serif; }
        body.dark-mode { --body-bg:#111827; --border-soft:#263244; --text-main:#e5e7eb; }
        .main-wrapper { min-height:100vh; margin-left:var(--sidebar-width); transition:var(--transition); }
        .main-wrapper.collapsed { margin-left:var(--sidebar-collapsed-width); }
        .topbar { position:sticky; top:0; height:var(--topbar-height); display:flex; align-items:center; justify-content:space-between; padding:0 26px; background:#fff; border-bottom:1px solid var(--border-soft); z-index:1020; }
        body.dark-mode .topbar, body.dark-mode .card, body.dark-mode .summary-card { background:#182131; color:var(--text-main); }
        .topbar-left, .topbar-right { display:flex; align-items:center; gap:14px; }
        .icon-btn { width:42px; height:42px; display:inline-flex; align-items:center; justify-content:center; border:0; border-radius:8px; color:#4b5563; background:#f4f6fb; }
        .icon-btn:hover { color:#fff; background:var(--purple); }
        .page-title-mini { display:flex; flex-direction:column; line-height:1.2; }
        .page-title-mini strong { color:var(--text-main); font-size:15px; font-weight:800; }
        .page-title-mini span { margin-top:3px; color:#7b8494; font-size:12px; font-weight:600; }
        .page-body { padding:clamp(22px, 2vw, 34px); }
        .workspace { width:100%; max-width:1540px; margin:0 auto; padding-inline:clamp(8px, 1.1vw, 18px); }
        body.navbar-sidebar-collapsed .workspace { max-width:1640px; padding-inline:clamp(10px, 1.4vw, 24px); }
        .card, .summary-card { border:1px solid var(--border-soft); border-radius:10px; box-shadow:0 10px 28px rgba(15,23,42,.05); }
        .summary-row { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:16px; margin-bottom:24px; }
        .summary-card { width:min(100%, 240px); min-height:112px; display:flex; flex-direction:column; justify-content:center; padding:20px 18px; background:#fff; border-left:5px solid #8b5cf6; }
        .summary-card strong { display:block; font-size:1.75rem; font-weight:800; line-height:1; }
        .summary-card p { margin:10px 0 0; color:#596274; font-size:.9rem; font-weight:800; line-height:1.25; }
        .btn-purple { --bs-btn-color:#fff; --bs-btn-bg:var(--purple); --bs-btn-border-color:var(--purple); --bs-btn-hover-color:#fff; --bs-btn-hover-bg:var(--purple-dark); --bs-btn-hover-border-color:var(--purple-dark); }
        .section-title { color:var(--text-main); font-size:1.05rem; font-weight:800; }
        .table-responsive { border-radius:10px; overflow-x:auto; }
        .arrived-table { width:100%; min-width:1320px; margin-bottom:0; table-layout:fixed; }
        .arrived-table th:nth-child(1), .arrived-table td:nth-child(1) { width:8%; }
        .arrived-table th:nth-child(2), .arrived-table td:nth-child(2) { width:10%; }
        .arrived-table th:nth-child(3), .arrived-table td:nth-child(3) { width:12%; }
        .arrived-table th:nth-child(4), .arrived-table td:nth-child(4) { width:17%; }
        .arrived-table th:nth-child(5), .arrived-table td:nth-child(5) { width:12%; }
        .arrived-table th:nth-child(6), .arrived-table td:nth-child(6) { width:8%; }
        .arrived-table th:nth-child(7), .arrived-table td:nth-child(7) { width:10%; }
        .arrived-table th:nth-child(8), .arrived-table td:nth-child(8) { width:12%; }
        .arrived-table th:nth-child(9), .arrived-table td:nth-child(9) { width:6%; }
        .arrived-table th:nth-child(10), .arrived-table td:nth-child(10) { width:5%; }
        .arrived-table th { padding:16px 12px; color:#596274; background:#f8f9fc; font-size:.86rem; font-weight:800; line-height:1.25; text-align:center; vertical-align:middle; }
        .arrived-table td { padding:17px 12px; color:var(--text-main); font-size:.9rem; font-weight:700; line-height:1.42; text-align:center; vertical-align:middle; overflow-wrap:anywhere; }
        .arrived-actions { display:inline-flex; justify-content:center; align-items:center; gap:7px; }
        .arrived-actions .btn { width:34px; height:34px; display:inline-flex; align-items:center; justify-content:center; padding:0; }
        .empty-row { padding:42px 16px !important; color:#8790a1 !important; text-align:center; }
        .detail-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); gap:12px; }
        .detail-box { padding:12px; border:1px solid var(--border-soft); border-radius:8px; background:#f8f9fc; }
        .detail-box span { display:block; color:#7b8494; font-size:.78rem; font-weight:800; text-transform:uppercase; }
        .detail-box strong { display:block; margin-top:4px; color:var(--text-main); font-size:.95rem; font-weight:800; }
        .receive-items-table { width:100%; min-width:980px; table-layout:fixed; }
        .receive-items-table th, .receive-items-table td { padding:10px; text-align:center; font-size:.84rem; vertical-align:middle; }
        .receive-items-table th { color:#596274; background:#f8f9fc; font-weight:800; white-space:nowrap; }
        .receive-items-table .product-cell { min-width:220px; text-align:left; white-space:normal; overflow-wrap:anywhere; }
        .receive-items-table .brand-cell { min-width:130px; white-space:normal; overflow-wrap:anywhere; }
        .receive-items-table input, .receive-items-table textarea, .receive-items-table select { min-width:74px; font-size:.83rem; }
        .receive-items-table .date-input { min-width:134px; }
        .receive-items-table .item-credit-cell { color:#475569; font-weight:800; white-space:nowrap; }
        .receive-validation-message { min-height:20px; color:#8a5a00; font-size:.84rem; font-weight:700; }
        #receiveArrivedOrderModal { --drp-modal-width:1180px; --drp-modal-max-width:1180px; --drp-modal-min-width:680px; }
        .payment-summary-card { width:min(100%, 520px); margin-left:auto; padding:14px 16px; border:1px solid #e5e7eb; border-radius:12px; background:#f6f7fb; box-shadow:0 10px 24px rgba(15,23,42,.04); }
        .payment-summary-card h3 { margin:0 0 10px; color:var(--text-main); font-size:1rem; font-weight:800; }
        .payment-summary-line { display:grid; grid-template-columns:minmax(150px, 1fr) auto; align-items:center; gap:14px; padding:7px 0; color:#596274; font-size:.88rem; font-weight:700; border-bottom:1px solid #e5e9f1; }
        .payment-summary-line:last-child { border-bottom:0; }
        .payment-summary-line strong { color:var(--text-main); text-align:right; white-space:nowrap; }
        .payment-summary-credit strong { color:#7a4d12; }
        .payment-summary-inputs { display:grid; grid-template-columns:1fr; gap:10px; padding:10px 0; border-bottom:1px solid #e5e9f1; }
        .payment-summary-total { margin-top:4px; padding-top:10px; color:var(--text-main); font-size:.96rem; border-top:2px solid #d8deeb; }
        .payment-summary-total strong { color:#4f46e5; font-size:1.1rem; }
        .payment-summary-reason { color:#6b7280; white-space:normal; overflow-wrap:anywhere; }
        .receipt-print-area { width:min(80mm, 100%); margin:0 auto; padding:10px 12px; color:#000; background:#fff; font-family:"Courier New", monospace; font-size:12px; line-height:1.35; }
        .receipt-print-area * { color:#000 !important; }
        .receipt-center { text-align:center; }
        .receipt-title { margin:0; font-size:16px; font-weight:800; letter-spacing:.3px; text-transform:uppercase; }
        .receipt-subtitle { margin:10px 0 8px; font-weight:800; text-align:center; text-transform:uppercase; }
        .receipt-divider { margin:10px 0; border-top:1px dashed #000; }
        .receipt-line { display:flex; justify-content:space-between; gap:10px; align-items:flex-start; }
        .receipt-line span:first-child { flex:0 0 auto; }
        .receipt-line span:last-child { min-width:0; text-align:right; overflow-wrap:anywhere; }
        .receipt-item { margin:9px 0 0; }
        .receipt-item-name { font-weight:800; overflow-wrap:anywhere; }
        .receipt-item-detail { padding-left:14px; overflow-wrap:anywhere; }
        .receipt-final { margin-top:8px; font-size:14px; font-weight:900; }
        .receipt-signatures { margin-top:12px; display:grid; gap:8px; }
        .success-check-list { display:grid; gap:10px; margin:10px 0 0; color:#1f2937; font-weight:800; }
        .success-check-list i { color:#16a34a; margin-right:8px; }
        @media print {
            body > *:not(#receivingReportModal) { display:none !important; }
            #receivingReportModal { position:static !important; display:block !important; opacity:1 !important; }
            #receivingReportModal .modal-dialog { width:80mm !important; max-width:80mm !important; margin:0 auto !important; }
            #receivingReportModal .modal-content { border:0 !important; box-shadow:none !important; resize:none !important; max-height:none !important; }
            #receivingReportModal .modal-header, #receivingReportModal .modal-footer { display:none !important; }
            #receivingReportModal .modal-body { overflow:visible !important; padding:0 !important; }
            .modal-backdrop { display:none !important; }
        }
        body.dark-mode .arrived-table th, body.dark-mode .receive-items-table th { background:#202b3d; color:#cbd5e1; }
        body.dark-mode .detail-box, body.dark-mode .payment-summary-card { background:#182131; }
        body.dark-mode .payment-summary-line { border-bottom-color:#263244; }
        @media (max-width: 900px) {
            #receiveArrivedOrderModal { --drp-modal-min-width:0px; }
            .payment-summary-card { margin-left:0; }
        }
        @media (max-width:991.98px) { .page-body { padding:20px 14px; } .workspace { max-width:100%; padding-inline:0; } }
    </style>
</head>
<body>
    <div id="navbar-container"></div>

    <main class="main-wrapper" id="mainWrapper">
        <header class="topbar">
            <div class="topbar-left">
                <button class="icon-btn" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="page-title-mini">
                    <strong>Arrived Orders</strong>
                    <span>Receive arrived purchase orders before stock-in</span>
                </div>
            </div>
            <div class="topbar-right">
                <button class="icon-btn" type="button" aria-label="Notifications">
                    <i class="fa-regular fa-bell"></i>
                </button>
                <button class="icon-btn" type="button" id="themeToggle" aria-label="Toggle dark mode">
                    <i class="fa-solid fa-moon"></i>
                </button>
            </div>
        </header>

        <section class="page-body">
            <div class="workspace">
                <div class="summary-row">
                    <div class="summary-card">
                        <strong id="arrivedOrderCount">0</strong>
                        <p>Arrived purchase orders</p>
                    </div>
                    <button class="btn btn-purple" type="button" id="btnRefreshArrivedOrders">
                        <i class="fa-solid fa-rotate me-2"></i>Refresh
                    </button>
                </div>

                <div class="card p-3">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
                        <div>
                            <h1 class="section-title mb-1">Arrived Purchase Orders</h1>
                            <p class="text-muted small mb-0">Receive good items into inventory and record damaged items separately.</p>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="table-arrived-orders" class="table table-hover align-middle arrived-table">
                            <thead>
                                <tr>
                                    <th>Order Date</th>
                                    <th>PO Number</th>
                                    <th>Supplier Name</th>
                                    <th>Items</th>
                                    <th>Brand Name</th>
                                    <th>Ordered Quantity</th>
                                    <th>Payment Terms</th>
                                    <th>Expected Delivery Date</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td colspan="10" class="empty-row">Loading arrived purchase orders...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <div class="modal fade" id="viewArrivedOrderModal" tabindex="-1" aria-labelledby="viewArrivedOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h2 class="modal-title fs-5 fw-bold" id="viewArrivedOrderModalLabel">Arrived Order Details</h2>
                        <p class="text-muted small mb-0 mt-1" id="viewArrivedPoNumber">Review complete order information.</p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="viewArrivedDetails" class="detail-grid mb-4"></div>
                    <div class="table-responsive border rounded">
                        <table class="table table-hover align-middle mb-0 receive-items-table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Brand Name</th>
                                    <th>Ordered Quantity</th>
                                    <th>Received Quantity</th>
                                    <th>Damaged Quantity</th>
                                    <th>Return Quantity</th>
                                </tr>
                            </thead>
                            <tbody id="viewArrivedItems"></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="receiveArrivedOrderModal" tabindex="-1" aria-labelledby="receiveArrivedOrderModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h2 class="modal-title fs-5 fw-bold" id="receiveArrivedOrderModalLabel">Receive Items</h2>
                        <p class="text-muted small mb-0 mt-1">PO <span id="receiveArrivedPoNumber">-</span> Ã‚Â· <span id="receiveArrivedSupplierName">-</span></p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive border rounded mb-3">
                        <table id="table-arrived-receive-items" class="table table-hover align-middle mb-0 receive-items-table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Brand Name</th>
                                    <th>Stock to Receive</th>
                                    <th>Supplier Unit Cost</th>
                                    <th>Received Quantity</th>
                                    <th>Damaged Quantity</th>
                                    <th>Damage Action</th>
                                    <th>Expiry Date</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                    <div class="row g-3 align-items-start mb-3">
                        <div class="col-lg-5 ms-auto">
                            <div class="payment-summary-card">
                                <h3>Payment Summary</h3>
                                <div class="payment-summary-line">
                                    <span>Original PO Total</span>
                                    <strong id="receiveOriginalTotal">Ã¢â€šÂ±0.00</strong>
                                </div>
                                <div class="payment-summary-line">
                                    <span>Rejected Qty</span>
                                    <strong id="receiveRejectedQty">0 items</strong>
                                </div>
                                <div class="payment-summary-line payment-summary-credit">
                                    <span>Supplier Credit</span>
                                    <strong id="receiveSupplierCredit">-Ã¢â€šÂ±0.00</strong>
                                </div>
                                <div class="payment-summary-inputs">
                                    <div>
                                        <label class="form-label small fw-bold mb-1" for="receiveSupplierDiscount">Supplier Discount</label>
                                        <div class="input-group input-group-sm">
                                            <span class="input-group-text">Ã¢â€šÂ±</span>
                                            <input id="receiveSupplierDiscount" class="form-control" type="number" min="0" step="0.01" value="0" inputmode="decimal">
                                        </div>
                                    </div>
                                </div>
                                <div class="payment-summary-line payment-summary-total">
                                    <span>Final Payment</span>
                                    <strong id="receiveFinalAmount">Ã¢â€šÂ±0.00</strong>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row g-3 mb-3 d-none">
                        <div class="col-md-4 ms-auto">
                            <label class="form-label fw-semibold" for="receiveArrivedAmountPaid">Amount Paid</label>
                            <div class="input-group">
                                <span class="input-group-text">Ã¢â€šÂ±</span>
                                <input id="receiveArrivedAmountPaid" class="form-control" type="number" min="0" step="0.01" placeholder="0.00">
                            </div>
                            <div class="form-text">Cannot exceed the purchase order total.</div>
                        </div>
                    </div>
                    <div id="receiveValidationMessage" class="receive-validation-message mb-2" aria-live="polite"></div>
                    <label class="form-label fw-semibold" for="receiveArrivedRemarks">Remarks</label>
                    <textarea id="receiveArrivedRemarks" class="form-control" rows="3" placeholder="Optional receiving notes..."></textarea>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Cancel</button>
                    <button id="btnConfirmArrivedReceive" class="btn btn-purple" type="button">Confirm Receive</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="receivingSuccessModal" tabindex="-1" aria-labelledby="receivingSuccessModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5 fw-bold" id="receivingSuccessModalLabel">Receiving Completed Successfully</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="success-check-list">
                        <div><i class="fa-solid fa-check"></i>Inventory Updated</div>
                        <div><i class="fa-solid fa-check"></i>Purchase Order Updated</div>
                        <div><i class="fa-solid fa-check"></i>Supplier Credit Recorded</div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button id="btnViewReceivingReport" class="btn btn-purple" type="button">View Receiving Report</button>
                    <button id="btnDownloadReceivingPdf" class="btn btn-outline-dark" type="button">Download PDF</button>
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="receivingReportModal" tabindex="-1" aria-labelledby="receivingReportModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <h2 class="modal-title fs-5 fw-bold" id="receivingReportModalLabel">Goods Received Note</h2>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="receivingReportContent" class="receipt-print-area"></div>
                </div>
                <div class="modal-footer">
                    <button id="btnDownloadReceivingPdfFromReport" class="btn btn-purple" type="button">Download PDF</button>
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.8.2/jspdf.plugin.autotable.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script type="module" src="./js/modules/arrived_orders.js?v=7"></script>
    <script type="module">
        import verifySession from './js/modules/auth.js';
        await verifySession();
    </script>
</body>
</html>
