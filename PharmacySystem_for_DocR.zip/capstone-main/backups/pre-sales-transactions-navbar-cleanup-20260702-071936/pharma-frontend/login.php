<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr. R Pharmacy | Login</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">

    <style>
        :root {
            --brand-purple: #8A2BE2;
            --brand-purple-dark: #7020bd;
            --page-bg: #f4f6fb;
            --text-main: #252b37;
            --text-muted: #747d8c;
            --border-soft: #e6eaf2;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            min-height: 100vh;
            font-family: "Inter", system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            color: var(--text-main);
            background:
                radial-gradient(circle at top left, rgba(138, 43, 226, 0.14), transparent 34%),
                linear-gradient(135deg, #f8f9fd 0%, var(--page-bg) 55%, #eef1f8 100%);
            letter-spacing: 0;
        }

        .login-card {
            width: min(100%, 420px);
            padding: 34px;
            border: 1px solid rgba(230, 234, 242, 0.86);
            border-radius: 14px;
            background: rgba(255, 255, 255, 0.94);
            box-shadow: 0 22px 60px rgba(31, 37, 48, 0.12);
            backdrop-filter: blur(12px);
        }

        .brand-icon {
            width: 58px;
            height: 58px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            color: #fff;
            background: linear-gradient(135deg, var(--brand-purple), #a855f7);
            font-size: 25px;
            box-shadow: 0 16px 30px rgba(138, 43, 226, 0.28);
        }

        .login-title {
            margin-top: 18px;
            margin-bottom: 6px;
            font-size: 25px;
            font-weight: 800;
            color: var(--text-main);
        }

        .login-subtitle {
            margin-bottom: 28px;
            color: var(--text-muted);
            font-size: 14px;
            font-weight: 500;
        }

        .form-label {
            color: #3f4654;
            font-size: 13px;
            font-weight: 700;
        }

        .input-group-text {
            width: 46px;
            justify-content: center;
            color: var(--brand-purple);
            background: #f7f4fc;
            border-color: var(--border-soft);
        }

        .form-control {
            min-height: 48px;
            border-color: var(--border-soft);
            font-size: 14px;
            font-weight: 500;
        }

        .form-control:focus {
            border-color: rgba(138, 43, 226, 0.48);
            box-shadow: 0 0 0 0.22rem rgba(138, 43, 226, 0.12);
        }

        .btn-login {
            min-height: 48px;
            border: 0;
            border-radius: 8px;
            background: var(--brand-purple);
            font-weight: 800;
            box-shadow: 0 14px 26px rgba(138, 43, 226, 0.22);
        }

        .btn-login:hover,
        .btn-login:focus {
            background: var(--brand-purple-dark);
        }

        .login-message {
            display: none;
            margin-bottom: 16px;
            padding: 12px 14px;
            border-radius: 8px;
            border: 1px solid #f3b4b4;
            color: #8a1f1f;
            background: #fff1f1;
            font-size: 13px;
            font-weight: 700;
            line-height: 1.45;
            overflow-wrap: anywhere;
        }

        .login-message.is-visible {
            display: block;
        }

        .login-footer {
            margin-top: 22px;
            color: var(--text-muted);
            font-size: 12px;
            font-weight: 600;
            text-align: center;
        }

        .toast {
            border-radius: 8px;
            box-shadow: 0 16px 40px rgba(31, 37, 48, 0.14);
        }
    </style>
</head>
<body>
    <main class="d-flex align-items-center justify-content-center min-vh-100 px-3 py-4">
        <section class="login-card">
            <div class="text-center">
                <div class="brand-icon">
                    <i class="fa-solid fa-prescription-bottle-medical"></i>
                </div>
                <h1 class="login-title">Dr. R Pharmacy</h1>
                <p class="login-subtitle">Sign in to continue to Pharmacy POS</p>
            </div>

            <form id="loginForm" novalidate>
                <div class="login-message" id="loginMessage" role="alert" aria-live="polite"></div>

                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-regular fa-user"></i></span>
                        <input type="text" class="form-control" id="username" name="username" placeholder="Enter username" autocomplete="username">
                    </div>
                </div>

                <div class="mb-4">
                    <label for="password" class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa-solid fa-lock"></i></span>
                        <input type="password" class="form-control" id="password" name="password" placeholder="Enter password" autocomplete="current-password">
                    </div>
                </div>

                <button type="submit" class="btn btn-primary btn-login w-100">
                    <i class="fa-solid fa-right-to-bracket me-2"></i>Login
                </button>
            </form>

            <div class="login-footer">Secure access for authorized pharmacy personnel</div>
        </section>
    </main>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <script type="module">
        import API_BASE_URL from './js/config/config.js';
        import { clearTabToken, setTabToken } from './js/modules/auth_guard.js?v=6';

        const loginForm = document.getElementById('loginForm');
        const usernameInput = document.getElementById('username');
        const passwordInput = document.getElementById('password');
        const loginMessage = document.getElementById('loginMessage');
        const submitButton = loginForm.querySelector('button[type="submit"]');

        clearTabToken();

        toastr.options = {
            closeButton: true,
            progressBar: true,
            positionClass: 'toast-bottom-right',
            timeOut: '2600'
        };

        function showLoginMessage(message) {
            loginMessage.textContent = message;
            loginMessage.classList.add('is-visible');
        }

        function clearLoginMessage() {
            loginMessage.textContent = '';
            loginMessage.classList.remove('is-visible');
        }

        loginForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            clearLoginMessage();

            const username = usernameInput.value.trim();
            const password = passwordInput.value;

            if (!username || !password) {
                showLoginMessage('Please fill in all fields');
                toastr.error('Please fill in all fields');
                return;
            }

            submitButton.disabled = true;

            try {
                const response = await fetch(`${API_BASE_URL}/auth/login.php`, {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ username, password })
                });

                let data = {};

                try {
                    data = await response.json();
                } catch (jsonErr) {
                    data = { message: 'Server returned an invalid response. Please check Apache and the API URL.' };
                }

                if (!response.ok) {
                    showLoginMessage(data.message || 'Login failed');
                    toastr.error(data.message || 'Login failed');
                    return;
                }

                if (!data.tab_token) {
                    showLoginMessage('Login could not create a secure tab session. Please try again.');
                    toastr.error('Login failed');
                    return;
                }

                setTabToken(data.tab_token);
                toastr.success('Login successful! Redirecting...');

                setTimeout(() => {
                    window.location.replace(data.redirect);
                }, 1500);
            } catch (err) {
                showLoginMessage(err.message || 'Login failed');
                toastr.error(err.message || 'Login failed');
            } finally {
                submitButton.disabled = false;
            }
        });
    </script>
</body>
</html>
