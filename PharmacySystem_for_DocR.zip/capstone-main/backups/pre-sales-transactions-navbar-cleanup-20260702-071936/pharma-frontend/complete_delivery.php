<?php
require_once __DIR__ . '/auth_page_guard.php';
?>
<!DOCTYPE html>
<html lang="en" data-bs-theme="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dr. R Pharmacy | Complete Delivery</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet">
    <link href="./css/navbar.css?v=15" rel="stylesheet">
    <script src="./js/navbar.js?v=28" defer></script>
    <script type="module" src="./js/modules/auth_guard.js?v=6"></script>

    <style>
        :root { --sidebar-width:260px; --sidebar-collapsed-width:70px; --purple:#7c3aed; --purple-dark:#6328d6; --body-bg:#f4f6fb; --topbar-height:70px; --border-soft:#e8ecf3; --text-main:#252b37; --transition:all .3s ease; }
        * { box-sizing:border-box; }
        body { margin:0; min-height:100vh; color:var(--text-main); background:var(--body-bg); font-family:"Inter", sans-serif; }
        body.dark-mode { --body-bg:#111827; --border-soft:#263244; --text-main:#e5e7eb; }
        .main-wrapper { min-height:100vh; margin-left:var(--sidebar-width); transition:var(--transition); }
        .main-wrapper.collapsed { margin-left:var(--sidebar-collapsed-width); }
        .topbar { position:sticky; top:0; height:var(--topbar-height); display:flex; align-items:center; justify-content:space-between; padding:0 26px; background:#fff; border-bottom:1px solid var(--border-soft); z-index:1020; }
        body.dark-mode .topbar, body.dark-mode .card, body.dark-mode .summary-card { background:#182131; color:var(--text-main); }
        .topbar-left, .topbar-right { display:flex; align-items:center; gap:14px; }
        .icon-btn { width:42px; height:42px; display:inline-flex; align-items:center; justify-content:center; border:0; border-radius:8px; color:#4b5563; background:#f4f6fb; }
        .icon-btn:hover { color:#fff; background:var(--purple); }
        .page-title-mini { display:flex; flex-direction:column; line-height:1.2; }
        .page-title-mini strong { color:var(--text-main); font-size:15px; font-weight:800; }
        .page-title-mini span { margin-top:3px; color:#7b8494; font-size:12px; font-weight:600; }
        .page-body { padding:clamp(22px, 2vw, 34px); }
        .workspace { width:100%; max-width:1580px; margin:0 auto; padding-inline:clamp(8px, 1.1vw, 18px); }
        body.navbar-sidebar-collapsed .workspace { max-width:1680px; padding-inline:clamp(10px, 1.4vw, 24px); }
        .card, .summary-card { border:1px solid var(--border-soft); border-radius:10px; box-shadow:0 10px 28px rgba(15,23,42,.05); }
        .summary-row { display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:16px; margin-bottom:24px; }
        .summary-card { width:min(100%, 240px); min-height:112px; display:flex; flex-direction:column; justify-content:center; padding:20px 18px; background:#fff; border-left:5px solid #16a34a; }
        .summary-card strong { display:block; font-size:1.75rem; font-weight:800; line-height:1; }
        .summary-card p { margin:10px 0 0; color:#596274; font-size:.9rem; font-weight:800; line-height:1.25; }
        .btn-purple { --bs-btn-color:#fff; --bs-btn-bg:var(--purple); --bs-btn-border-color:var(--purple); --bs-btn-hover-color:#fff; --bs-btn-hover-bg:var(--purple-dark); --bs-btn-hover-border-color:var(--purple-dark); }
        .section-title { color:var(--text-main); font-size:1.05rem; font-weight:800; }
        .table-responsive { border-radius:10px; overflow-x:auto; }
        #table-complete-delivery.complete-delivery-table { width:100%; min-width:1700px!important; margin-bottom:0; table-layout:fixed; }
        .complete-delivery-table th { padding:14px 9px; color:#596274; background:#f8f9fc; font-size:12px; font-weight:800; line-height:1.18; text-align:center; vertical-align:middle; }
        .complete-delivery-table td { padding:15px 9px; color:var(--text-main); font-size:12px; font-weight:750; line-height:1.32; text-align:center; vertical-align:middle; }
        .complete-delivery-table th:nth-child(1), .complete-delivery-table td:nth-child(1) { width:115px; white-space:nowrap; }
        .complete-delivery-table th:nth-child(2), .complete-delivery-table td:nth-child(2) { width:170px; white-space:nowrap; }
        .complete-delivery-table th:nth-child(3), .complete-delivery-table td:nth-child(3) { width:165px; }
        .complete-delivery-table th:nth-child(4), .complete-delivery-table td:nth-child(4) { width:230px; }
        .complete-delivery-table th:nth-child(5), .complete-delivery-table td:nth-child(5) { width:150px; }
        .complete-delivery-table th:nth-child(6), .complete-delivery-table td:nth-child(6),
        .complete-delivery-table th:nth-child(7), .complete-delivery-table td:nth-child(7) { width:110px; }
        .complete-delivery-table th:nth-child(8), .complete-delivery-table td:nth-child(8),
        .complete-delivery-table th:nth-child(9), .complete-delivery-table td:nth-child(9) { width:130px; white-space:nowrap; }
        .complete-delivery-table th:nth-child(10), .complete-delivery-table td:nth-child(10),
        .complete-delivery-table th:nth-child(11), .complete-delivery-table td:nth-child(11) { width:125px; white-space:nowrap; }
        .complete-delivery-table th:nth-child(12), .complete-delivery-table td:nth-child(12) { width:112px; min-width:112px; white-space:nowrap; }
        .line-list { display:grid; gap:4px; margin:0; padding:0; list-style:none; text-align:left; }
        .line-list li { display:grid; grid-template-columns:18px minmax(0, 1fr); gap:5px; align-items:start; }
        .line-list .idx { color:#7b8494; font-size:12px; font-weight:800; text-align:right; }
        .line-list .txt { min-width:0; overflow-wrap:break-word; word-break:normal; }
        .line-list.plain { text-align:center; }
        .line-list.plain li { grid-template-columns:1fr; justify-items:center; }
        .money-nowrap, .status-badge { white-space:nowrap; }
        .complete-actions { display:inline-flex; justify-content:center; align-items:center; gap:7px; white-space:nowrap; }
        .complete-actions .btn { width:32px; height:32px; display:inline-flex; align-items:center; justify-content:center; padding:0; }
        .empty-row { padding:42px 16px !important; color:#8790a1 !important; text-align:center; }
        .detail-grid { display:grid; grid-template-columns:repeat(auto-fit, minmax(190px, 1fr)); gap:12px; }
        .detail-box { padding:12px; border:1px solid var(--border-soft); border-radius:8px; background:#f8f9fc; }
        .detail-box span { display:block; color:#7b8494; font-size:.78rem; font-weight:800; text-transform:uppercase; }
        .detail-box strong { display:block; margin-top:4px; color:var(--text-main); font-size:.95rem; font-weight:800; }
        .details-table th, .details-table td { padding:12px; text-align:center; font-size:.88rem; vertical-align:middle; }
        .details-table th { color:#596274; background:#f8f9fc; font-weight:800; white-space:nowrap; }
        body.dark-mode .complete-delivery-table th, body.dark-mode .details-table th { background:#202b3d; color:#cbd5e1; }
        body.dark-mode .detail-box { background:#182131; }
        @media (max-width:991.98px) { .page-body { padding:20px 14px; } .workspace { max-width:100%; padding-inline:0; } }
    </style>
</head>
<body>
    <div id="navbar-container"></div>

    <main class="main-wrapper" id="mainWrapper">
        <header class="topbar">
            <div class="topbar-left">
                <button class="icon-btn" type="button" id="sidebarToggle" aria-label="Toggle sidebar">
                    <i class="fa-solid fa-bars"></i>
                </button>
                <div class="page-title-mini">
                    <strong>Complete Delivery</strong>
                    <span>Delivered purchase orders and final payment review</span>
                </div>
            </div>
            <div class="topbar-right">
                <button class="icon-btn" type="button" aria-label="Notifications">
                    <i class="fa-regular fa-bell"></i>
                </button>
                <button class="icon-btn" type="button" id="themeToggle" aria-label="Toggle dark mode">
                    <i class="fa-solid fa-moon"></i>
                </button>
            </div>
        </header>

        <section class="page-body">
            <div class="workspace">
                <div class="summary-row">
                    <div class="summary-card">
                        <strong id="completeDeliveryCount">0</strong>
                        <p>Completed deliveries</p>
                    </div>
                    <button class="btn btn-purple" type="button" id="btnRefreshCompleteDelivery">
                        <i class="fa-solid fa-rotate me-2"></i>Refresh
                    </button>
                </div>

                <div class="card p-3">
                    <div class="d-flex flex-wrap align-items-center justify-content-between gap-3 mb-3">
                        <div>
                            <h1 class="section-title mb-1">Complete Delivery</h1>
                            <p class="text-muted small mb-0">Delivered purchase orders that already passed receiving.</p>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table id="table-complete-delivery" class="table table-hover align-middle complete-delivery-table">
                            <thead>
                                <tr>
                                    <th>Delivery Date</th>
                                    <th>PO Number</th>
                                    <th>Supplier Name</th>
                                    <th>Items</th>
                                    <th>Brand Name</th>
                                    <th>Ordered Quantity</th>
                                    <th>Received Quantity</th>
                                    <th>Total Amount</th>
                                    <th>Final Payment</th>
                                    <th>Payment Status</th>
                                    <th>Status</th>
                                    <th class="col-actions">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr><td colspan="12" class="empty-row">Loading completed deliveries...</td></tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </main>

    <div class="modal fade" id="completeDeliveryDetailsModal" tabindex="-1" aria-labelledby="completeDeliveryDetailsModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-header">
                    <div>
                        <h2 class="modal-title fs-5 fw-bold" id="completeDeliveryDetailsModalLabel">Complete Delivery Details</h2>
                        <p class="text-muted small mb-0 mt-1" id="completeDeliveryPoNumber">Review delivered purchase order details.</p>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div id="completeDeliveryDetails" class="detail-grid mb-4"></div>
                    <div class="table-responsive border rounded">
                        <table class="table table-hover align-middle mb-0 details-table">
                            <thead>
                                <tr>
                                    <th>Product Name</th>
                                    <th>Brand Name</th>
                                    <th>Ordered Qty</th>
                                    <th>Received Qty</th>
                                    <th>Damaged/Returned Qty</th>
                                    <th>Unit Price</th>
                                    <th>Returned Amount</th>
                                </tr>
                            </thead>
                            <tbody id="completeDeliveryItems"></tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script>
    <script type="module" src="./js/modules/complete_delivery.js?v=3"></script>
    <script type="module">
        import verifySession from './js/modules/auth.js';
        await verifySession();
    </script>
</body>
</html>
