<?php
$allowedRoles = ['super_admin', 'admin', 'Admin', 'ro-super-admin', 'ro-admin'];
require_once '../../config/db_connection.php';
require_once '../../config/require_auth.php';
require_once '../products/product_category_schema.php';
require_once '../products/product_pricing_schema.php';
require_once 'supplier_schema.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Only POST requests are allowed.']);
    exit();
}

$payload = json_decode(file_get_contents('php://input'), true);
if (!is_array($payload)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Invalid JSON payload.']);
    exit();
}

function supplierProductText(array $payload, string $field): ?string
{
    $value = trim((string) ($payload[$field] ?? ''));
    return $value === '' || strcasecmp($value, 'N/A') === 0 ? null : $value;
}

function supplierProductRequiredText(array $payload, string $field): string
{
    $value = trim((string) ($payload[$field] ?? ''));
    if ($value === '') {
        throw new InvalidArgumentException(str_replace('_', ' ', ucfirst($field)) . ' is required.');
    }
    return $value;
}

function supplierProductNumberOrNull(array $payload, string $field): ?float
{
    $value = trim((string) ($payload[$field] ?? ''));
    if ($value === '') {
        return null;
    }
    if (!is_numeric($value) || (float) $value < 0) {
        throw new InvalidArgumentException(str_replace('_', ' ', ucfirst($field)) . ' must be a valid number.');
    }
    return (float) $value;
}

function supplierProductPositiveInt(array $payload, string $field): int
{
    $value = trim((string) ($payload[$field] ?? ''));
    if (!is_numeric($value) || (float) $value <= 0) {
        throw new InvalidArgumentException('Units per Purchase Unit must be numeric and greater than 0.');
    }
    return (int) $value;
}

function supplierProductJoin(?string ...$parts): ?string
{
    $clean = array_values(array_filter(array_map(static fn($part) => trim((string) ($part ?? '')), $parts), static fn($part) => $part !== ''));
    return count($clean) ? implode(' ', $clean) : null;
}

try {
    ensureProductPricingSchema($pdo);
    $supplierProductId = cleanId($payload['supplier_product_id'] ?? null);
    $supplierId = cleanId($payload['supplier_id'] ?? null);
    $productId = cleanId($payload['product_id'] ?? null);
    $categoryId = cleanId($payload['category_id'] ?? null);
    $typeId = cleanId($payload['type_id'] ?? null);
    $brandName = supplierProductRequiredText($payload, 'brand_name');
    $productName = supplierProductRequiredText($payload, 'product_name');
    $supplierCost = supplierProductNumberOrNull($payload, 'supplier_cost_price');
    $purchaseUnit = supplierProductText($payload, 'purchase_unit');
    $unitsPerPurchaseUnit = supplierProductPositiveInt($payload, 'units_per_purchase_unit');

    if ($supplierCost === null) {
        throw new InvalidArgumentException('Supplier cost must be a non-negative number.');
    }
    if ($purchaseUnit === null) {
        throw new InvalidArgumentException('Purchase Unit is required.');
    }
    ensureSupplierProductInventoryUnitColumn($pdo);
    ensureSupplierPurchasingConversionSchema($pdo);
    $inventoryUnit = productInventoryUnitForSupplier($pdo,$productId)['unit_name'];

    if ($supplierProductId === '' || $supplierId === '' || $productId === '') {
        throw new InvalidArgumentException('A valid supplier product link is required.');
    }
    if ($categoryId === '') {
        throw new InvalidArgumentException('A valid product category is required.');
    }
    if ($typeId === '' || getProductTypeId($pdo, $categoryId, $typeId) === null) {
        throw new InvalidArgumentException('A valid product type is required for the selected category.');
    }

    $categoryStatement = $pdo->prepare('SELECT category_name FROM product_categories WHERE category_id = :category_id LIMIT 1');
    $categoryStatement->execute([':category_id' => $categoryId]);
    $categoryName = (string) $categoryStatement->fetchColumn();
    if ($categoryName === '') {
        throw new InvalidArgumentException('A valid product category is required.');
    }

    $linkCheck = $pdo->prepare(
        'SELECT purchase_unit, inner_unit, inventory_unit
         FROM supplier_products
         WHERE supplier_product_id = :supplier_product_id
           AND supplier_id = :supplier_id
           AND product_id = :product_id'
    );
    $linkCheck->execute([
        ':supplier_product_id' => $supplierProductId,
        ':supplier_id' => $supplierId,
        ':product_id' => $productId
    ]);
    $savedHierarchy = $linkCheck->fetch(PDO::FETCH_ASSOC);
    if (!$savedHierarchy) {
        throw new InvalidArgumentException('Supplier product link was not found.');
    }
    validateSupplierPurchasingHierarchyUnits($pdo, [
        'purchase_unit' => (string) $purchaseUnit,
        'inventory_unit' => (string) $inventoryUnit,
        'units_per_purchase_unit' => $unitsPerPurchaseUnit,
    ], $savedHierarchy);

    $unit = supplierProductText($payload, 'unit');
    $packaging = supplierProductText($payload, 'packaging');
    $genericName = supplierProductText($payload, 'generic_name');
    $variant = supplierProductText($payload, 'variant_flavor');
    $strengthValue = supplierProductNumberOrNull($payload, 'strength_value');
    $strengthUnit = supplierProductText($payload, 'strength_unit');
    $strength = supplierProductText($payload, 'strength') ?? supplierProductJoin($strengthValue === null ? null : (string) $strengthValue, $strengthUnit);
    $dosageForm = supplierProductText($payload, 'dosage_form') ?? $unit;
    $netContentValue = supplierProductNumberOrNull($payload, 'net_content_value');
    $netContentUnit = supplierProductText($payload, 'net_content_unit');
    $size = supplierProductText($payload, 'size_value');
    $netWeight = supplierProductText($payload, 'net_weight');
    if ($categoryName === 'Grocery' && $netWeight !== null && !is_numeric($netWeight)) {
        throw new InvalidArgumentException('Net weight must be a number only.');
    }
    $material = supplierProductText($payload, 'material');
    $sterileStatus = supplierProductText($payload, 'sterile_status');
    $packContentQty = supplierProductText($payload, 'pack_content_qty');
    $packContentUnit = supplierProductText($payload, 'pack_content_unit') ?? $unit;
    $packContent = supplierProductText($payload, 'pack_content') ?? supplierProductJoin($packContentQty, $packContentUnit);

    $pdo->beginTransaction();

    $productStatement = $pdo->prepare(
        'UPDATE product
         SET category_id = :category_id,
             type_id = :type_id,
             brand_name = :brand_name,
             product_name = :product_name
         WHERE product_id = :product_id'
    );
    $productStatement->execute([
        ':category_id' => $categoryId,
        ':type_id' => $typeId,
        ':brand_name' => $brandName,
        ':product_name' => $productName,
        ':product_id' => $productId
    ]);

    if ($categoryName === 'Medicine') {
        $exists = $pdo->prepare('SELECT medicine_detail_id FROM medicine_details WHERE product_id = :product_id LIMIT 1');
        $exists->execute([':product_id' => $productId]);

        if (cleanId($exists->fetchColumn()) !== '') {
            $detail = $pdo->prepare(
                'UPDATE medicine_details
                 SET strength = :strength,
                     strength_value = :strength_value,
                     strength_unit = :strength_unit,
                     generic_name = :generic_name,
                     dosage_form = :dosage_form,
                     net_content_value = :net_content_value,
                     net_content_unit = :net_content_unit,
                     package_type = :package_type
                 WHERE product_id = :product_id'
            );
            $detail->execute([
                ':strength' => $strength,
                ':strength_value' => $strengthValue,
                ':strength_unit' => $strengthUnit,
                ':generic_name' => $genericName,
                ':dosage_form' => $dosageForm,
                ':net_content_value' => $netContentValue,
                ':net_content_unit' => $netContentUnit,
                ':package_type' => $packaging,
                ':product_id' => $productId
            ]);
        } else {
            $detail = $pdo->prepare(
                'INSERT INTO medicine_details (medicine_detail_id, product_id, generic_name, strength_value, strength_unit, strength, dosage_form, net_content_value, net_content_unit, package_type)
                 VALUES (:medicine_detail_id, :product_id, :generic_name, :strength_value, :strength_unit, :strength, :dosage_form, :net_content_value, :net_content_unit, :package_type)'
            );
            $detail->execute([
                ':medicine_detail_id' => newUuid($pdo),
                ':product_id' => $productId,
                ':generic_name' => $genericName,
                ':strength_value' => $strengthValue,
                ':strength_unit' => $strengthUnit,
                ':strength' => $strength,
                ':dosage_form' => $dosageForm,
                ':net_content_value' => $netContentValue,
                ':net_content_unit' => $netContentUnit,
                ':package_type' => $packaging
            ]);
        }

        $pdo->prepare('DELETE FROM grocery_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
        $pdo->prepare('DELETE FROM medical_supply_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
    } elseif ($categoryName === 'Grocery') {
        $exists = $pdo->prepare('SELECT grocery_detail_id FROM grocery_details WHERE product_id = :product_id LIMIT 1');
        $exists->execute([':product_id' => $productId]);

        if (cleanId($exists->fetchColumn()) !== '') {
            $detail = $pdo->prepare(
                'UPDATE grocery_details
                 SET variant = :variant,
                     size = :size,
                     net_weight = :net_weight,
                     unit = :unit,
                     package_type = :package_type,
                     pack_content = :pack_content
                 WHERE product_id = :product_id'
            );
            $detail->execute([
                ':variant' => $variant,
                ':size' => $size,
                ':net_weight' => $netWeight,
                ':unit' => $unit,
                ':package_type' => $packaging,
                ':pack_content' => $packContent,
                ':product_id' => $productId
            ]);
        } else {
            $detail = $pdo->prepare(
                'INSERT INTO grocery_details (grocery_detail_id, product_id, variant, size, net_weight, unit, package_type, pack_content)
                 VALUES (:grocery_detail_id, :product_id, :variant, :size, :net_weight, :unit, :package_type, :pack_content)'
            );
            $detail->execute([
                ':grocery_detail_id' => newUuid($pdo),
                ':product_id' => $productId,
                ':variant' => $variant,
                ':size' => $size,
                ':net_weight' => $netWeight,
                ':unit' => $unit,
                ':package_type' => $packaging,
                ':pack_content' => $packContent
            ]);
        }

        $pdo->prepare('DELETE FROM medicine_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
        $pdo->prepare('DELETE FROM medical_supply_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
    } elseif (in_array($categoryName, ['Medical Supply', 'Medical Supplies'], true)) {
        $exists = $pdo->prepare('SELECT medical_supply_detail_id FROM medical_supply_details WHERE product_id = :product_id LIMIT 1');
        $exists->execute([':product_id' => $productId]);

        if (cleanId($exists->fetchColumn()) !== '') {
            $detail = $pdo->prepare(
                'UPDATE medical_supply_details
                 SET variant = :variant,
                     size = :size,
                     material = :material,
                     sterile_status = :sterile_status,
                     package_type = :package_type,
                     pack_content = :pack_content
                 WHERE product_id = :product_id'
            );
            $detail->execute([
                ':variant' => $variant,
                ':size' => $size,
                ':material' => $material,
                ':sterile_status' => $sterileStatus,
                ':package_type' => $packaging,
                ':pack_content' => $packContent,
                ':product_id' => $productId
            ]);
        } else {
            $detail = $pdo->prepare(
                'INSERT INTO medical_supply_details (medical_supply_detail_id, product_id, variant, size, material, sterile_status, package_type, pack_content)
                 VALUES (:medical_supply_detail_id, :product_id, :variant, :size, :material, :sterile_status, :package_type, :pack_content)'
            );
            $detail->execute([
                ':medical_supply_detail_id' => newUuid($pdo),
                ':product_id' => $productId,
                ':variant' => $variant,
                ':size' => $size,
                ':material' => $material,
                ':sterile_status' => $sterileStatus,
                ':package_type' => $packaging,
                ':pack_content' => $packContent
            ]);
        }

        $pdo->prepare('DELETE FROM medicine_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
        $pdo->prepare('DELETE FROM grocery_details WHERE product_id = :product_id')->execute([':product_id' => $productId]);
    }

    $supplierStatement = $pdo->prepare(
        'UPDATE supplier_products
         SET supplier_cost_price = :supplier_cost_price,
             supplier_cost_input = :supplier_cost_input,
             supplier_cost_basis = :supplier_cost_basis,
             purchase_unit = :purchase_unit,
             purchase_unit_contains = :purchase_unit_contains,
             inner_unit = NULL,
             units_per_inner_unit = NULL,
             inventory_unit = :inventory_unit,
             units_per_purchase_unit = :units_per_purchase_unit
         WHERE supplier_product_id = :supplier_product_id
           AND supplier_id = :supplier_id
           AND product_id = :product_id'
    );
    $supplierStatement->execute([
        ':supplier_cost_price' => $supplierCost / $unitsPerPurchaseUnit,
        ':supplier_cost_input' => $supplierCost,
        ':supplier_cost_basis' => 'purchase',
        ':purchase_unit' => $purchaseUnit,
        ':purchase_unit_contains' => $unitsPerPurchaseUnit,
        ':inventory_unit' => $inventoryUnit,
        ':units_per_purchase_unit' => $unitsPerPurchaseUnit,
        ':supplier_product_id' => $supplierProductId,
        ':supplier_id' => $supplierId,
        ':product_id' => $productId
    ]);
    syncSupplierProductUnitConversions($pdo,$supplierProductId,[
        'purchase_unit'=>$purchaseUnit,
        'purchase_unit_contains'=>$unitsPerPurchaseUnit,
        'inventory_unit'=>$inventoryUnit,
        'units_per_purchase_unit'=>$unitsPerPurchaseUnit,
    ]);

    $pdo->commit();

    echo json_encode([
        'status' => 'success',
        'message' => 'Supplier quotation updated. Active selling price was not changed.',
        'pricing' => productPricingSnapshot($pdo, $productId),
        'quotation_preview' => [
            'supplier_cost_per_inventory_unit' => round($supplierCost / $unitsPerPurchaseUnit, 4),
            'estimated_purchase_unit_cost' => round($supplierCost, 2),
            'calculated_selling_price' => calculatedSellingPrice($supplierCost / $unitsPerPurchaseUnit, productPricingSnapshot($pdo, $productId)['applied_markup_percentage']),
        ]
    ]);
} catch (InvalidArgumentException $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Unable to update supplier product.', 'error' => $e->getMessage()]);
}
?>
